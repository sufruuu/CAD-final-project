Title: [FINAL] RC CAR CAD Drawing
-------------------------------------------------------
CAD Tool: Fusion 360
Submitted by: T S Subramaniyan
--------------------------------------------------------
Link to view the project files: https://a360.co/49RShfW
--------------------------------------------------------
Files Included:
	- Image of the final design
	- .F3Z File to open in Fusion 360
	- .STEP File of the project
	- Link to view in Fusion 360
--------------------------------------------------------